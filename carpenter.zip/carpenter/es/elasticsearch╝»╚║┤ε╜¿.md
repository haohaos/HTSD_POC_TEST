---
title: ES集群搭建
---

>Elasticsearch 6.5.1 

1. 下载

   > 地址 https://artifacts.elastic.co/downloads/elasticsearch/elasticsearch-6.5.1.tar.gz

2. 修改配置文件  elasticsearch-6.5.1/config/elasticsearch.yml

   > cluster.name: bizseer  #集群名称  
   >
   > path.data: /path/to/data  #指定数据存储路径
   >
   > path.data: /path/to/data  #指定日志存储路径
   >
   > network.host: ip_addr  #指定当前机器ip
   >
   > http.port: 9200  #指定端口 默认为9200
   >
   > discovery.zen.ping.unicast.hosts: [host1，host2, ...]  #指定集群初始化时的节点
   
   > http.cors.enabled: true
   > http.cors.allow-origin: "*"  #若不添加  header插件无法连接
3. 在三台机器上执行`elasticsearch-6.5.1/bin/elasticsearch -d`启动


> 可能出现的错误

若`ps -ef | grep elasticsearch`发现没有es进程，查看日志发现有报错信息如：

* `max virtual memory areas vm.max_map_count [65530] likely too low`

  解决办法: 

  `su - root`

  `vi /etc/sysctl.conf`

  在文件末尾添加  `vm.max_map_count=262144`

  `sysctl -p`
* `max file descriptors [4096] for elasticsearch process likely too low`

  解决办法:

  `su - root`

  `vi /etc/security/limits.conf  `

  在文件末尾添加 

  `* soft nofile 65536`

  `*hard nofile 131072`

  `* soft nproc 2048`

  `*hard nproc 4096`

  切换为es用户 使用`ulimit -n `查看最大进程数是否修改了65536 若未修改 需要退出bash重新登录
