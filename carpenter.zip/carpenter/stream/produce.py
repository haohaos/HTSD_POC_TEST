import threading, time, os, sys, json
from kafka import KafkaProducer

class Producer(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        self.stop_event = threading.Event()

    def stop(self):
        self.stop_event.set()
        
    def run(self):
        producer = KafkaProducer(bootstrap_servers='localhost:9092')

        base_dir = sys.argv[1]
        batch = 1
        if len(sys.argv) > 2:
            batch = int(sys.argv[2])

        logs = {}
        for i in os.listdir(base_dir):
            if i[-4:] == '.log':
                with open(os.path.join(base_dir, i)) as f:
                    logs[i[:-4]] = map(lambda x: json.dumps({'log_key': i[:-4], 'raw': x.strip()}), f.readlines())
        
        index = 0
        while not self.stop_event.is_set():
            while True:
                for i in logs.values():
                    producer.send('carpenter-in', i[index % len(i)])
                index += 1
                if index % batch == 0:
                    break
            time.sleep(1)
            
        producer.close()


if __name__ == '__main__':
    task = Producer()
    task.start()
    raw_input("press any key to stop")
    task.stop()
