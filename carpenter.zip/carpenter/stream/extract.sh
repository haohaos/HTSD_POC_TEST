#!/bin/bash
export SPARK_HOME=/Library/spark/spark-2.4.0-bin-hadoop2.7
export RESTAPI_URI=http://localhost:5000

while :
do
${SPARK_HOME}/bin/spark-submit \
  --class com.bizseer.anomaly.carpenter.CLI \
  --master local[1] \
  --driver-memory 10g \
  ~/Desktop/carpenter/target/carpenter.jar extract \
  --debug \
  -li stream -ko stream \
  -ru ${RESTAPI_URI}
echo 'press any key to restart the extractor, or Ctrl-C to quit'
read
done