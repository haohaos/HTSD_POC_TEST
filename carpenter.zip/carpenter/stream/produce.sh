#!/usr/bin/env bash
export KAFKA_HOME=/usr/local/Cellar/kafka/2.1.0
export LOG_FILE_DIR=~/Desktop/carpenter/log
export BATCH_SIZE=10

nohup ${KAFKA_HOME}/bin/zookeeper-server-start.sh ${KAFKA_HOME}/config/zookeeper.properties &
echo 'zookeeper started'
sleep 2s
nohup ${KAFKA_HOME}/bin/kafka-server-start.sh ${KAFKA_HOME}/config/server.properties &
echo 'kafka server started'
sleep 2s

${KAFKA_HOME}/bin/kafka-topics.sh --create --zookeeper localhost:2181 --replication-factor 1 --partitions 1 --topic carpenter-in
${KAFKA_HOME}/bin/kafka-topics.sh --create --zookeeper localhost:2181 --replication-factor 1 --partitions 1 --topic carpenter-out
${KAFKA_HOME}/bin/kafka-topics.sh --create --zookeeper localhost:2181 --replication-factor 1 --partitions 1 --topic carpenter-kpi
${KAFKA_HOME}/bin/kafka-topics.sh --list --zookeeper localhost:2181

echo "press any key to start producing logs"
read
python produce.py ${LOG_FILE_DIR} ${BATCH_SIZE}

${KAFKA_HOME}/bin/kafka-topics.sh --delete --zookeeper localhost:2181 --topic carpenter-in
${KAFKA_HOME}/bin/kafka-topics.sh --delete --zookeeper localhost:2181 --topic carpenter-out
${KAFKA_HOME}/bin/kafka-topics.sh --delete --zookeeper localhost:2181 --topic carpenter-kpi
${KAFKA_HOME}/bin/kafka-server-stop.sh
sleep 2s
${KAFKA_HOME}/bin/zookeeper-server-stop.sh
sleep 2s
ps -A | grep kafka | awk '{print $1}' | xargs kill -9 $1
