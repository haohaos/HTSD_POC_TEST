0. 需要检查的变量：
 SPARK_HOME    # stream.sh & extract.sh
 KAFKA_HOME    # produce.sh
 LOG_FILE_DIR  # produce.sh

-------------------------------------------------------------------------------

streaming测试使用方法：

1. 运行restapi。可以是carpenter-web自带的基于flask的，也可以是anomaly-restapi
2. 确定将需要测试的日志模型和抽取设置（如果需要测试抽取功能的话）接入restapi
3. 将对应的日志分名称（需要和日志模型名称对应）放到logs目录内
4. 运行produce.sh，确定zk和kafka开启无误
5. 运行stream.sh，确定流处理开启无误
6. 在produce.sh进程确认进入下一阶段，开始推送数据
7. 从carpenter-out的topic可以开始接受处理过的数据

--------------------------------------------------------------------------------

kpi streaming测试方法：

1. 运行restapi，将model和log接入。
2. 在model中写入extract rule
3. 运行produce.sh
5. 运行stream.sh，确定流处理开启无误
6. 在produce.sh进程确认进入下一阶段，开始推送数据
7. 在文件或carpenter-kpi的topic可以开始接受处理过的数据